# This mirror is deprecated, please start using the [official repository](https://packagist.org/packages/phpoffice/phpexcel)!


### PHPExcel package for composer

This is a mirror of the PHPExcel library by [CodePlex](http://phpexcel.codeplex.com). The mirror **doesn't contain documentation or tests**.

This mirror has been created to make PHPExcel installable with [Composer](http://packagist.org/).

If you would like to install PHPExcel as a [Composer](http://packagist.org/) package, add a file called `composer.json` to the root of your project and add the following:

    {
        "require": {
            "CodePlex/PHPExcel": "1.7.8"
        }
    }

If you already have a `composer.json` file, just add an attitional requirement for PHPExcel.

You can also install the following earlier versions of PHPExcel via Composer:

- 1.7.7
- 1.7.6

### Thanks and Disclaimer
Many thanks to the CodePlex guys for this great library! This repo is an unaltered mirror of their work to make PHPExcel composer installable as long as they don't have their own solution in place. I take neither credit nor responsibility for anything that might happen to you due to the use of this package :).
